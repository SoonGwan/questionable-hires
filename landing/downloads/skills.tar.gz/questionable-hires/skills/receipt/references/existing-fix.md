# Receipt for an existing fix

This guide covers Python. For an existing `node --test` project, read only the
[native Node comparison guide](node-comparison.md) instead.

Compare isolated implementations with **the same current assertions/inputs** and
comparable dependencies/configuration; reuse valid evidence. Identify loaded
revisions. Setup/old-interface failures are not defect reproduction. Preserve
entrypoint scope and stopping rules; do not install dependencies. Retrospective
comparison does not satisfy a requirement to observe failure before editing.

Select support/configuration from actual test imports/inputs. List unresolved
paths only; select known directories directly. Selection size is not completeness.

## Execute the comparison

Reuse a project-native comparison that already establishes the required isolation,
assertions, loaded code and preservation. The Python helper is an option when its
copying, same-process import checks and cleanup replace missing setup; supporting
the language alone is not a reason to replace an adequate existing runner.
Native isolation is also valid, and necessary for unsupported runtimes,
added/deleted implementations or retained copies. Keep the same evidence requirements
whichever path is chosen. Read implementation for a concrete trust, adaptation or
diagnosis question; the CLI recipes below do not require importing the helper API.

The helper creates `.receipt-*` scratch **under `--source`**, with separate
`before`/`after` copies, and cleans up its owned copies on exit. Confirm
`comparison_copies_removed` in the result; cleanup failure is not success.
Tests run from their respective copies; only child environments receive the
copy-local import/temp setup. This does not contain trusted test side effects.
`guard_tree` below already covers preservation around the comparison: no separate
preservation wrapper is needed. The recipes and option contracts here are enough
for supported use; follow detail links for an unresolved compatibility question.

When verification must preserve Git metadata too, use
`git --no-optional-locks -c diff.autoRefreshIndex=false` for status/diff review.
This suppresses optional index refresh, not other command/driver side effects;
it does not make mutating commands read-only or change persistent Git settings.

Adapt **one** example's paths/tests/revisions; HEAD/HEAD^ are placeholders.
Neither writes a recipe, commits, stashes nor reverses user patches.
Recipe keys must be unique, including nested objects. Invalid input reports
duplicate, missing or unknown keys before running a comparison; correct those keys
instead of dropping a requested check.

Committed fix:

```sh
python3 /path/to/receipt/scripts/compare.py --source . --spec - <<'JSON'
{"fixed":["test_parser.py"],"vary":["parser.py"],"before":"HEAD^","after":"HEAD","imports":["parser"],"runner":"unittest","tests":["-v","test_parser"]}
JSON
```

Already-present uncommitted fix:

```sh
python3 /path/to/receipt/scripts/compare.py --source . --spec - <<'JSON'
{"fixed":["test_parser.py"],"vary":["parser.py"],"before":"HEAD","after":{"working_tree":true},"imports":["parser"],"runner":"unittest","tests":["-v","test_parser"]}
JSON
```

- `fixed`: required, permitted current tests/data/config/dependencies, files or
  directories including hidden leaves. Frozen once for both copies; leaf hashes
  appear in `fixed_sha256`.
- `vary`: implementation files, required in both variants. `before`/string `after`
  resolve and report full commit IDs; no separate revision lookup is needed.
  Working-tree `after` freezes current bytes/modes, **not staged content**;
  `revisions.after=null`, `working_tree_after` hashes/modes identify selected files,
  not a commit or whole-repository snapshot.
- Optional `"watch":["notes.txt"]`: existing files/directories checked, **not
  copied/executed**. `originals` gives selected hashes/modes/unchanged status;
  `comparison_copies_removed` gives cleanup. Reuse those selected-file checks.
- For a requested comparison of several past versions against the same current
  tests, unittest supports `"additional_before":["release-a","release-b"]`.
  Distinct commits run as `before`, `before_2`, `before_3`, then `after` **once**;
  `checks` and `revisions` use those labels. Inputs are frozen once, all versions
  are prepared before execution, and one shared snapshot budget still applies.
  At most seven extras; per-check timeout and incomplete-evidence stopping remain.
  Inspect each actual failure, not just the shared after pass. This replaces
  repeated pairwise helper calls, not an adequate native multi-version runner;
  it is not independent confirmation or appropriate for different tests/runtimes.
- Optional `"guard_tree":true`: only for requested whole-project preservation
  with all reads authorized. Checks Git/ignored entries, bytes/modes and link text
  around comparison; changes abort without restoration. It excludes link targets,
  timestamps/other metadata, concurrent or restored changes and other commands.
  `tree_guard` reports counts/digest; limits are 10,000 entries/20 MB per inventory.
  See [guard details](comparison-details.md#preservation-guards) for boundary questions.
- Selections must be canonical project-relative, unique and disjoint after
  expansion; no root, Git internals, symlinks, empty directories or overlap.
  `fixed`/`vary` must be nonempty. Directory traversal: at most 10,000 entries.
- `imports` must resolve inside each native test process's copy. Use the project
  interpreter (default: launching Python; override `--python` if needed), unittest
  or already-installed pytest. Pytest verifies imports after native collection,
  before test bodies, preserving configuration and assertion rewriting.
  Child temp defaults are inside each copy: do not
  redirect global TMPDIR merely to localize checks or other launchers may pollute it.
- For a dynamically loaded module held by a declared import, optional
  `"module_bindings":{"test_loader:component":"plugin.py"}` checks that module's
  `__file__` against the selected fixed/varying file in the same native process.
  `test_loader` must also be in `imports`. Dotted attributes traverse module
  dictionaries only: no expressions, properties, arbitrary objects or function
  identity checks. Missing/wrong bindings produce incomplete evidence before
  tests, not regression failures. Checks occur before unittest execution or after
  pytest collection; fixtures/later reassignment and actual dispatch require
  project-native assertions. Plain `imports` verifies modules, not their attributes.
- Optional `"invocation":"module"`: for required `python -B -m unittest ...`,
  with `runner: "unittest"` and existing `tests`; no internal adapter needed.
  Default is `bootstrap`. Copy-local startup checks imports in the native test
  process; inspect `command`, `native_exit_code`, `provenance_ready` and
  `suite_observation`. Both unittest modes record completion; missing results or
  exit disagreement map to incomplete check7 and stop later comparisons. Empty
  and all-skipped native results retain their exit; they are not regression proof.
  Conventional existing system/user hooks are preserved. Project-local or unusual
  startup customization needs native project setup, not a bypass; read
  [startup compatibility](comparison-details.md#native-module-startup) when applicable.
- Optional `"observe_assertions":true`: only when actual argument values are
  required, for unittest in either invocation mode. Adds `assertion_observation`
  for current-thread standard `assertEqual`/`assertIsNot` calls, without replacing
  assertions. `actual`/`expected` mean first/second arguments, not inferred roles.
  Format `v:3`: primitive builtins and exact standard pathlib types. Paths use
  `{"PosixPath":"..."}` (or `WindowsPath`, `PurePosixPath`, `PureWindowsPath`);
  lexical text is limited to 256 characters, with no resolving or subclass
  conversion. Lists are JSON arrays, tuples use
  `{"tuple":[...]}`, bytes use `{"bytes_hex":"..."}`. Older stored reports without
  `v` use kind/items containers; v2 lacks Path encoding. Do not relabel either as v3. Limits:
  4,096 report bytes, 64 records, 32 value nodes per argument pair, container depth
  three and length sixteen. No arbitrary object representation or thread coverage.
  Existing/replaced profile hooks, unsupported values, empty observation, limit
  overflow or missing/error reports mean incomplete check7/CLI2 and stop later
  versions; inspect `reason` and retained `native_exit_code`. `complete` covers
  only this observation scope, not all tests/assertions. Default off adds no field
  and does not load the observer. General model-token/time savings remain unproven.
- Optional `"import_roots":["src"]` supports regular source-layout packages.
  Select initializers/support too; each root must contain selected files.
  Ordered canonical roots precede each copy's root and appear in the result.
  No inherited PYTHONPATH, editable install, build hook or installed metadata;
  use native project setup when required. Only when that native workflow lacks
  preservation, [preservation-only support](native-preservation.md) supplies the
  bounded guard without replacing the runner; it does not copy or execute tests.

## Read the evidence, not just the exit code

Use default compact JSON for agent execution; it retains every field and native
output. Reserve `--pretty` for a human-readable JSON request, not extra evidence.

After a returned check, ordinary copy/runner/cleanup errors retain partial JSON
with `status:"incomplete"` and `execution_error`; final preservation failures use
`preservation_error`. CLI still exits 2. Missing results remain unknown, and copy
removal can be null when unverified; see [failure details](comparison-details.md#preservation-guards).

CLI 0 means observations collected, **not proof**. Inspect each actual assertion,
requested test identity, before failure/after pass, copied-import evidence,
`exit_code`, `timed_out` and `output_truncated`. Help/version output is not execution.
Each `Verified copied import:` line includes the resolved module `path` and native
process `pid`. This records import-time location, not proof against subsequent
monkey-patching; a truncated line is unavailable evidence, not permission to infer it.
Skipped/empty checks do not establish a regression, even with native exit 0.
Missing import/startup provenance or check exit 7 means incomplete: CLI 2, no next
comparison. Preserve native errors, not just the wrapper status. See
[exit interpretation](comparison-details.md#exit-interpretation) for runner-specific
counts, import errors or early-exit diagnosis.

Python 3.9+/POSIX, trusted tests only: **not a sandbox**. Copies are removed;
`originals` checks selected bytes/modes, not arbitrary effects or new entries.
Test paths/subprocesses can escape; snapshots are not atomic. Guard limitations
are detailed in [preservation guards](comparison-details.md#preservation-guards).

Copying: shared 20 MB budget; overflow aborts before tests, not a partial comparison.
Execution: 30 seconds/check (`--timeout` up to 300), last 12,000 output characters.
Required work must finish in the foreground: remaining process-group members are
killed after runner exit; persistent background jobs are unsupported. Cleanup can
wait five more seconds; unconfirmed exit means incomplete, no next comparison.
Do not retry automatically while prior work may remain. For budget, output or
cleanup questions read [resource/process boundaries](comparison-details.md#resource-and-process-boundaries).
