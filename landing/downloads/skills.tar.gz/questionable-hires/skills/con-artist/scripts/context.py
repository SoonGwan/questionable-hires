#!/usr/bin/env python3
"""Read an explicit Python audit slice and its ancestor context; never import it."""

import argparse
import ast
import bisect
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import sys
import tokenize


MAX_FILE = 256_000
MAX_INPUT = 2_000_000
MAX_OUTPUT = 100_000
FULL_SOURCE_LINES = 200
CONFIGS = ('pytest.ini', '.pytest.ini', 'pyproject.toml', 'tox.ini', 'setup.cfg')
DEFINITIONS = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)


def checked(root, relative):
    path = Path(relative)
    if path.is_absolute() or not path.parts or '..' in path.parts or '.git' in path.parts:
        raise ValueError('Expected a project-relative path without traversal or Git internals')
    if len(path.parts) > 32:
        raise ValueError('Path nesting exceeds 32 components')
    current = root
    for part in path.parts:
        current = current / part
        if current.is_symlink():
            raise ValueError('Symlinks are not supported: ' + str(path))
    return current


def read(root, path, budget):
    source = checked(root, path)
    info = source.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_FILE:
        raise ValueError('Expected a regular file of at most 256000 bytes: ' + str(path))
    if budget[0] + info.st_size > MAX_INPUT:
        raise ValueError('Selected context exceeds 2000000 input bytes')
    # Validate the opened object, not only the path inspected above. Nonblocking
    # open prevents a raced FIFO from waiting for a writer on supported systems.
    flags = os.O_RDONLY | getattr(os, 'O_NONBLOCK', 0) | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0)
    descriptor = os.open(source, flags)
    with os.fdopen(descriptor, 'rb') as stream:
        opened = os.fstat(stream.fileno())
        if (not stat.S_ISREG(opened.st_mode)
                or (opened.st_dev, opened.st_ino) != (info.st_dev, info.st_ino)):
            raise ValueError('Selected file changed while opening: ' + str(path))
        if opened.st_size > MAX_FILE or budget[0] + opened.st_size > MAX_INPUT:
            raise ValueError('Opened file exceeds context read budget: ' + str(path))
        data = stream.read(MAX_FILE + 1)
    if len(data) > MAX_FILE:
        raise ValueError('File exceeded read limit: ' + str(path))
    budget[0] += len(data)
    if budget[0] > MAX_INPUT:
        raise ValueError('Selected context exceeds 2000000 input bytes')
    # An initial UTF-8 signature is encoding metadata, not an AST source column.
    # Budgets and identity still cover every original byte, including the marker.
    return data.decode('utf-8-sig'), hashlib.sha256(data).hexdigest()


def span(node, source=None, cache=None):
    decorators = getattr(node, 'decorator_list', [])
    first = min([node.lineno] + [d.lineno for d in decorators])
    if decorators and source is not None:
        # AST decorator positions start at the expression, potentially after @(
        # or an explicit continuation. Reuse one logical-token scan per snapshot.
        if cache is None:
            cache = {}
        if 'decorator_openings' not in cache:
            openings, statement_start = [], True
            with io.StringIO(source, newline=None) as stream:
                for token in tokenize.generate_tokens(stream.readline):
                    if token.type == tokenize.NEWLINE:
                        statement_start = True
                    elif token.type not in (tokenize.NL, tokenize.COMMENT,
                                            tokenize.INDENT, tokenize.DEDENT):
                        if statement_start and token.string == '@':
                            openings.append(token.start[0])
                        statement_start = False
            cache['decorator_openings'] = openings
        openings = cache['decorator_openings']
        index = bisect.bisect_right(openings, first) - 1
        if index < 0:
            raise ValueError('Cannot locate the opening decorator token')
        first = openings[index]
    return first, node.end_lineno


def excerpt(lines, first, last):
    return '\n'.join(f'{i}: {lines[i - 1]}' for i in range(first, last + 1))


def physical_lines(source):
    # Python line numbers recognize LF, CRLF and CR, not all Unicode separators
    # accepted by str.splitlines(). Keep those characters inside source literals.
    lines = source.replace('\r\n', '\n').replace('\r', '\n').split('\n')
    if lines[-1] == '':
        lines.pop()
    return lines


def definition_spans(tree, source=None, cache=None):
    if cache is None:
        cache = {}
    records = []
    def visit(node, prefix=''):
        if isinstance(node, DEFINITIONS):
            name = prefix + node.name
            first, last = span(node, source, cache)
            records.append((first, last, name, node))
            prefix = name + '.'
        for child in ast.iter_child_nodes(node):
            # Expressions cannot contain definition statements. Traversing a
            # deeply nested value must not break an unrelated source selector.
            if not isinstance(child, ast.expr):
                visit(child, prefix)
    visit(tree)
    return records


def definition_at_line(tree, line, spans=None):
    if spans is None:
        spans = definition_spans(tree)
    matches = [(last - first, name, node) for first, last, name, node in spans
               if first <= line <= last]
    if not matches:
        raise ValueError('Line is outside a Python definition; select the full file for module context')
    matches.sort(key=lambda item: item[0])
    if len(matches) > 1 and matches[0][0] == matches[1][0]:
        raise ValueError('Line has ambiguous enclosing definitions')
    return matches[0][1:]


def definition_index(body, source, prefix='', segments=None, cache=None):
    if cache is None:
        cache = {}
    # AST columns are UTF-8 byte offsets. Split Python physical lines once,
    # retaining original terminators; str.splitlines also splits literal data.
    if segments is None:
        segments = re.findall(rb'[^\r\n]*(?:\r\n|\r|\n|$)', source.encode('utf-8'))
    def decorator_source(node):
        first, last = node.lineno - 1, node.end_lineno - 1
        if first == last:
            return segments[first][node.col_offset:node.end_col_offset].decode('utf-8')
        return (segments[first][node.col_offset:] + b''.join(segments[first+1:last]) +
                segments[last][:node.end_col_offset]).decode('utf-8')
    records = []
    for node in body:
        if not isinstance(node, DEFINITIONS):
            continue
        first, last = span(node, source, cache)
        name = prefix + node.name
        records.append(dict(name=name, kind=type(node).__name__, first_line=first,
                            last_line=last, decorators=[decorator_source(d)
                                                        for d in node.decorator_list]))
        if isinstance(node, ast.ClassDef):
            records.extend(definition_index(node.body, source, name + '.', segments, cache))
    return records


def scope_definitions(body):
    """Yield static definitions through control flow, but not nested scopes."""
    for node in body:
        if isinstance(node, DEFINITIONS):
            yield node
        elif not isinstance(node, ast.expr):
            yield from scope_definitions(ast.iter_child_nodes(node))


def describe(root, path, budget, symbol=None, index=False, auto_index=False, cache=None, pretty=False, all_matches=False):
    # Invocation-local only: multiple excerpts must share the same source bytes.
    if cache is None:
        cache = {}
    if path not in cache:
        source, digest = read(root, path, budget)
        cache[path] = dict(source=source, digest=digest, lines=physical_lines(source))
    snapshot = cache[path]
    source, digest, lines = snapshot['source'], snapshot['digest'], snapshot['lines']
    result = dict(path=str(path), sha256=digest)
    large_selected = auto_index and Path(path).suffix == '.py' and len(lines) > FULL_SOURCE_LINES and not symbol
    index = index or large_selected
    if symbol or index:
        if 'tree' not in snapshot:
            snapshot['tree'] = ast.parse(source, filename=str(path))
        tree = snapshot['tree']
        if symbol:
            if isinstance(symbol, int):
                if symbol > len(lines):
                    raise ValueError('Selected line exceeds file length: ' + str(path))
                result['requested_line'] = symbol
                if 'definition_spans' not in snapshot:
                    snapshot['definition_spans'] = definition_spans(tree, source, snapshot)
                symbol, node = definition_at_line(tree, symbol, snapshot['definition_spans'])
            else:
                body = tree.body
                scopes = snapshot.setdefault('scope_names', {})
                parts = symbol.split('.')
                for position, name in enumerate(parts):
                    key = id(body)  # The parsed tree owns these lists for this snapshot.
                    if key not in scopes:
                        names = {}
                        for definition in scope_definitions(body):
                            names.setdefault(definition.name, []).append(definition)
                        scopes[key] = names
                    matches = scopes[key].get(name, [])
                    if all_matches and position == len(parts) - 1 and matches:
                        definitions = []
                        for match in sorted(matches, key=span):
                            first, last = span(match, source, snapshot)
                            definitions.append(dict(kind=type(match).__name__, first_line=first,
                                last_line=last, source=excerpt(lines, first, last)))
                        result.update(representation='definition_group', symbol=symbol,
                            definitions=definitions,
                            limitation='All static definitions at the named leaf, not a selected runtime implementation. Enclosing conditions, imports, globals, assignments and bindings are unresolved.')
                        return result
                    if len(matches) != 1:
                        raise ValueError('Missing or ambiguous definition: ' + str(path) + ':' + symbol)
                    node = matches[0]
                    body = node.body
            first, last = span(node, source, snapshot)
            result.update(representation='definition', symbol=symbol, source=excerpt(lines, first, last))
            result['limitation'] = 'Definition excerpt only; imports, globals, bases and runtime bindings are not resolved.'
        else:
            definitions, top_level = definition_index(tree.body, source, cache=snapshot), []
            for node in tree.body:
                first, last = span(node)
                if not isinstance(node, DEFINITIONS):
                    top_level.append(excerpt(lines, first, last))
            result.update(representation='definition_index', bodies_omitted=True,
                          definitions=definitions, top_level=top_level,
                          limitation='Static index only; definition/class bodies are omitted, not reviewed. Inspect relevant definitions, fixtures, hooks and plugins before execution. Module-level conditional definitions remain in top_level; conditions inside class bodies are omitted. Runtime bindings are unresolved.')
            if large_selected:
                result['reason'] = 'Selected Python file exceeds 200 lines; use file:qualified.definition or --full to read bodies. No behavioral conclusion is established by this index.'
                index_size = len(encode({'selected': [result]}, pretty))
                # Full numbered source cannot be shorter than its bare line
                # contents. Avoid constructing it when the index already wins;
                # prefixes, separators and JSON escaping only add characters.
                if index_size < sum(map(len, lines)):
                    return result
                full_result = dict(path=str(path), sha256=digest, representation='full_source',
                                   source=excerpt(lines, 1, len(lines)))
                # Compare at the actual selected-record nesting depth: pretty
                # indentation adds more bytes to a multi-record index than to
                # the single escaped source string. Ancestor context is common
                # to both choices and does not affect this difference.
                if index_size >= len(encode({'selected': [full_result]}, pretty)):
                    return full_result
    else:
        result['representation'] = 'full_source'
        result['source'] = excerpt(lines, 1, len(lines))
    return result


def encode(result, pretty=False):
    return json.dumps(result, ensure_ascii=False, indent=2 if pretty else None,
                      separators=None if pretty else (',', ':'))


def collect(root, selectors, full=False, *, pretty=False, all_matches=False, max_output=None):
    if max_output is None:
        max_output = MAX_OUTPUT
    if type(max_output) is not int or not 1 <= max_output <= MAX_OUTPUT:
        raise ValueError(f'max_output must be an integer from 1 to {MAX_OUTPUT} characters')
    root = Path(root).resolve(strict=True)
    if not root.is_dir() or not 1 <= len(selectors) <= 8:
        raise ValueError('Provide a project directory and 1–8 file[:definition-or-line] selectors')
    selected, directories = [], {Path('.')}
    budget = [0]
    cache = {}
    for selector in selectors:
        path_text, separator, symbol = selector.partition(':')
        path = Path(path_text)
        checked(root, path)
        if separator:
            if symbol.isascii() and symbol.isdecimal() and len(symbol) <= 6 and str(int(symbol)) == symbol and int(symbol) > 0:
                symbol = int(symbol)
            elif not symbol or not all(s.isidentifier() for s in symbol.split('.')):
                raise ValueError('Expected a dotted Python definition name or positive canonical line number')
        selected.append((path, symbol if separator else None))
        directories.update(path.parents)
    ordered = sorted(directories, key=lambda p: (len(p.parts), p.as_posix()))
    instructions, configs, conftests, checked_instructions = [], [], [], []
    for directory in ordered:
        for name in ('AGENTS.md', 'AGENTS.override.md', *CONFIGS, 'conftest.py'):
            relative = directory / name
            candidate = checked(root, relative)
            if name.startswith('AGENTS'):
                checked_instructions.append(str(relative))
            if not candidate.exists():
                continue
            record = describe(root, relative, budget, index=name == 'conftest.py', cache=cache)
            if name.startswith('AGENTS'):
                instructions.append(record)
            elif name == 'conftest.py':
                conftests.append(record)
            else:
                configs.append(record)
    result = dict(status='collected', instructions=instructions,
                  instruction_paths_checked=checked_instructions, configs=configs,
                  conftest_indexes=conftests,
                  selected=[describe(root, path, budget, symbol, auto_index=not full, cache=cache, pretty=pretty, all_matches=all_matches) for path, symbol in selected],
                  limitation='Read-only navigation, not execution or complete dependency/config discovery. Only selected-path ancestors inside the supplied root are checked. Host instructions still apply; inspect additional dependencies when needed. Files must remain stable while reading.')
    if len(encode(result, pretty)) + 1 > max_output:  # CLI's terminating newline
        raise ValueError(f'Context exceeds {max_output} characters; narrow selectors or use project tools. No partial context emitted.')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path.cwd())
    parser.add_argument('--full', action='store_true',
                        help='Return full selected files instead of indexing Python files over 200 lines; size limits still apply')
    parser.add_argument('--pretty', action='store_true',
                        help='Indent JSON for manual inspection; default JSON is compact with identical values')
    parser.add_argument('--all-matches', action='store_true',
                        help='For named selectors, return every static leaf definition (including overloads); ambiguous parent scopes still fail. Does not resolve runtime bindings.')
    parser.add_argument('--max-output', type=int, default=None, metavar='CHARACTERS',
                        help='Lower the complete JSON output limit (including final newline); 1–100000 characters, not a token budget. Never truncates source.')
    parser.add_argument('selectors', nargs='+', metavar='FILE[:DEFINITION_OR_LINE]')
    args = parser.parse_args()
    try:
        result = collect(args.root, args.selectors, full=args.full, pretty=args.pretty, all_matches=args.all_matches, max_output=args.max_output)
    except (OSError, ValueError, SyntaxError, RecursionError) as error:
        print(json.dumps(dict(status='incomplete', error=str(error))), file=sys.stderr)
        return 2
    print(encode(result, args.pretty))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
